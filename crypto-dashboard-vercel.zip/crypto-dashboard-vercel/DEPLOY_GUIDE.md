# 🚀 Гайд по деплою Crypto Dashboard на Vercel

## ⚡ Быстрый старт (5 минут)

### 1. Подготовь проект
```bash
# Распакуй папку crypto-dashboard-vercel
# Все файлы уже готовы!
```

### 2. Создай репозиторий на GitHub
1. Иди на https://github.com/new
2. Назови репозиторий: `crypto-dashboard-ai`
3. Сделай его публичным
4. НЕ добавляй README, .gitignore (они уже есть)
5. Нажми "Create repository"

### 3. Залей код на GitHub
```bash
cd crypto-dashboard-vercel

# Инициализируй git
git init
git add .
git commit -m "Initial commit: Crypto Dashboard AI"

# Добавь remote (замени YOUR_USERNAME на свой)
git remote add origin https://github.com/YOUR_USERNAME/crypto-dashboard-ai.git

# Залей код
git branch -M main
git push -u origin main
```

### 4. Задеплой на Vercel
1. Иди на https://vercel.com
2. Нажми "Sign Up" → выбери "Continue with GitHub"
3. Авторизуйся через GitHub
4. Нажми "Import Project"
5. Найди свой репозиторий `crypto-dashboard-ai`
6. Нажми "Import"
7. Настройки:
   - Framework Preset: **Next.js** (автоматически определится)
   - Root Directory: `./` (оставь как есть)
   - Build Command: `npm run build` (автоматически)
   - Output Directory: `.next` (автоматически)
8. Нажми **"Deploy"**
9. Жди 2-3 минуты ⏳

### 5. Готово! 🎉
Vercel даст тебе ссылку типа:
```
https://crypto-dashboard-ai-username.vercel.app
```

Открывай на любом устройстве!

---

## 📱 Как открыть на телефоне

1. Просто открой ссылку Vercel в браузере телефона
2. Нажми "Добавить на главный экран" (iOS) или "Установить приложение" (Android)
3. Готово! Теперь работает как приложение 📲

---

## 🔧 Если что-то пошло не так

### Ошибка: "NOT_FOUND" или 404
**Причина:** Файл `app/page.js` не найден

**Решение:**
1. Убедись, что структура такая:
   ```
   crypto-dashboard-vercel/
   ├── app/
   │   ├── page.js       ← ВАЖНО! Должен быть
   │   ├── layout.js
   │   └── globals.css
   ├── package.json
   ├── next.config.js
   └── ...
   ```
2. Если файла нет, скопируй из исходников
3. Сделай commit и push:
   ```bash
   git add .
   git commit -m "Fix: add page.js"
   git push
   ```
4. Vercel автоматически передеплоит

### Ошибка при билде
**Причина:** Проблема с зависимостями

**Решение:**
1. Проверь `package.json` - все зависимости на месте?
2. В настройках Vercel → Settings → General → Node.js Version → выбери `18.x`
3. Redeploy

### Ошибка с localStorage
**Причина:** SSR (Server-Side Rendering) не имеет доступа к браузеру

**Решение:** Уже исправлено! В `page.js` используется проверка `typeof window !== 'undefined'`

---

## 🎨 Кастомизация

### Изменить домен
1. В Vercel → Settings → Domains
2. Добавь свой домен или измени поддомен

### Обновить код
```bash
# Внеси изменения в код
git add .
git commit -m "Update features"
git push

# Vercel автоматически передеплоит за 1-2 минуты
```

### Добавить переменные окружения
1. В Vercel → Settings → Environment Variables
2. Добавь API ключи если нужны

---

## 📊 Мониторинг

### Посмотреть логи
1. Vercel Dashboard → Deployments
2. Выбери деплой → Logs
3. Смотри ошибки в реальном времени

### Аналитика
1. Vercel → Analytics
2. Смотри количество визитов, производительность

---

## ❓ FAQ

**Q: Бесплатно ли это?**
A: Да! Vercel дает бесплатно:
- Безлимитные деплои
- 100GB bandwidth/месяц
- Автоматические SSL сертификаты
- CI/CD из коробки

**Q: Можно ли использовать другой хостинг?**
A: Да, можно деплоить на:
- Netlify
- Cloudflare Pages  
- Railway
- Render

Но Vercel - лучший для Next.js (они создатели Next.js)

**Q: Как обновить данные криптовалют?**
A: Приложение автоматически обновляет данные каждую минуту через CoinGecko API

**Q: Можно добавить больше криптовалют?**
A: Да! Открой `app/page.js` и отредактируй массив `cryptoConfig`

---

## 🎯 Чеклист перед деплоем

- [ ] Все файлы на месте (особенно `app/page.js`)
- [ ] package.json корректный
- [ ] Код залит на GitHub
- [ ] Vercel подключен к GitHub репозиторию
- [ ] Framework Preset = Next.js
- [ ] Деплой запущен

---

## 🆘 Поддержка

Если ничего не помогло:
1. Проверь консоль браузера (F12) на ошибки
2. Проверь Vercel Deployment Logs
3. Погугли ошибку + "Next.js Vercel"
4. Спроси в Discord сообществе Next.js

---

**Удачи! Теперь у тебя свой крипто-дашборд с AI! 🚀💎**
