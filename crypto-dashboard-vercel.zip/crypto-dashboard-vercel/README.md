# 🚀 Crypto Dashboard AI

![Next.js](https://img.shields.io/badge/Next.js-14-black)
![React](https://img.shields.io/badge/React-18-blue)
![Tailwind](https://img.shields.io/badge/Tailwind-3-cyan)
![License](https://img.shields.io/badge/license-MIT-green)

## 📊 Что это?

Современный крипто-дашборд с AI советником, который помогает отслеживать портфолио и получать инсайты по криптовалютам в реальном времени.

### ✨ Основные фичи

- 📈 **Реальные данные** - цены и графики через CoinGecko API
- 🤖 **AI Советник** - интерактивный чат для анализа портфолио
- 💼 **Портфолио трекер** - отслеживай свои активы
- 📱 **Адаптивный дизайн** - работает на всех устройствах
- 🎨 **Современный UI** - футуристичный дизайн с градиентами
- ⚡ **Быстрый** - оптимизирован для производительности

### 🎯 Поддерживаемые криптовалюты

- Bitcoin (BTC)
- Ethereum (ETH)
- Solana (SOL)
- Cardano (ADA)
- Polkadot (DOT)
- Avalanche (AVAX)

## 🚀 Быстрый старт

### Требования
- Node.js 18+ 
- npm или yarn

### Локальная разработка

```bash
# Установи зависимости
npm install

# Запусти dev сервер
npm run dev

# Открой http://localhost:3000
```

### Деплой на Vercel

Смотри полный гайд в [DEPLOY_GUIDE.md](./DEPLOY_GUIDE.md)

Быстрая версия:
```bash
# Залей на GitHub
git init
git add .
git commit -m "Initial commit"
git remote add origin YOUR_GITHUB_REPO
git push -u origin main

# Потом просто импортируй в Vercel
```

## 📁 Структура проекта

```
crypto-dashboard-vercel/
├── app/
│   ├── page.js          # Главный компонент
│   ├── layout.js        # Layout с метаданными
│   └── globals.css      # Глобальные стили
├── package.json         # Зависимости
├── next.config.js       # Настройки Next.js
├── tailwind.config.js   # Настройки Tailwind
└── DEPLOY_GUIDE.md      # Гайд по деплою
```

## 🎨 Технологии

- **Framework**: Next.js 14 (App Router)
- **UI**: React 18 + Tailwind CSS
- **Charts**: Recharts
- **Icons**: Lucide React
- **API**: CoinGecko (бесплатный тариф)
- **Storage**: localStorage (портфолио)

## 💡 Как использовать

### 1. Просмотр цен
Смотри актуальные цены и изменения за 24 часа в верхних карточках

### 2. Графики
Кликни на криптовалюту → увидишь график с периодами 24ч/7д/30д

### 3. Портфолио
Твое портфолио сохраняется в браузере автоматически

### 4. AI Советник
Нажми на кнопку чата → задай вопрос:
- "Проанализируй мое портфолио"
- "Что думаешь про Solana?"
- "Куда лучше инвестировать?"

## 🔧 Кастомизация

### Добавить криптовалюту

В `app/page.js` найди:
```javascript
const cryptoConfig = [
  { id: 'bitcoin', symbol: 'BTC', icon: '₿' },
  // Добавь свою:
  { id: 'ripple', symbol: 'XRP', icon: '✕' },
];
```

> ID берется из CoinGecko API

### Изменить цвета

В `tailwind.config.js`:
```javascript
theme: {
  extend: {
    colors: {
      'crypto-primary': '#06b6d4',  // Меняй здесь
    }
  }
}
```

## 📈 API Rate Limits

CoinGecko Free Tier:
- 10-30 запросов/минуту
- Достаточно для личного использования
- Если нужно больше → добавь API key в .env

## 🐛 Troubleshooting

### Ошибка 404 NOT_FOUND
Убедись что `app/page.js` существует и экспортирует компонент по умолчанию

### Не загружаются данные
1. Проверь консоль браузера (F12)
2. CoinGecko API может быть недоступен
3. Используется fallback данные автоматически

### localStorage не работает
Это нормально при SSR. Код уже содержит проверку `typeof window`

## 📄 Лицензия

MIT License - используй как хочешь!

## 🤝 Контрибьют

Pull requests welcome! Открывай issues если нашел баг.

## 📧 Контакты

Вопросы? Открывай issue в GitHub!

---

**Made with 💎 by crypto enthusiasts**
