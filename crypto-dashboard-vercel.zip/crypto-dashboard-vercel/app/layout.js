import './globals.css'

export const metadata = {
  title: 'Crypto Dashboard AI',
  description: 'AI-powered cryptocurrency dashboard with real-time data',
}

export default function RootLayout({ children }) {
  return (
    <html lang="ru">
      <head>
        <link 
          href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@400;600;700&display=swap" 
          rel="stylesheet" 
        />
      </head>
      <body>{children}</body>
    </html>
  )
}
