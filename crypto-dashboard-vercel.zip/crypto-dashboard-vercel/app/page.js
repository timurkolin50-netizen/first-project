'use client'

import React, { useState, useEffect, useRef } from 'react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Zap, Globe, RefreshCw, MessageSquare, Send, Bot, Sparkles, Target, AlertCircle } from 'lucide-react';

export default function CryptoDashboard() {
  const [selectedCrypto, setSelectedCrypto] = useState('bitcoin');
  const [portfolioValue, setPortfolioValue] = useState(0);
  const [timeframe, setTimeframe] = useState('24h');
  const [cryptoData, setCryptoData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [chartData, setChartData] = useState([]);
  const [lastUpdate, setLastUpdate] = useState(null);
  const [news, setNews] = useState([]);
  
  // AI Chat состояние
  const [chatMessages, setChatMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isAITyping, setIsAITyping] = useState(false);
  const chatEndRef = useRef(null);

  // AI Рекомендации
  const [aiRecommendations, setAiRecommendations] = useState(null);
  const [loadingRecommendations, setLoadingRecommendations] = useState(false);

  // Конфигурация криптовалют
  const cryptoConfig = [
    { id: 'bitcoin', symbol: 'BTC', icon: '₿' },
    { id: 'ethereum', symbol: 'ETH', icon: 'Ξ' },
    { id: 'solana', symbol: 'SOL', icon: '◎' },
    { id: 'cardano', symbol: 'ADA', icon: '₳' },
    { id: 'polkadot', symbol: 'DOT', icon: '●' },
    { id: 'avalanche-2', symbol: 'AVAX', icon: '▲' }
  ];

  // Портфолио с сохранением в localStorage
  const [portfolio, setPortfolio] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cryptoPortfolio');
      return saved ? JSON.parse(saved) : [
        { symbol: 'BTC', amount: 0.5, avgPrice: 65000 },
        { symbol: 'ETH', amount: 5, avgPrice: 3500 },
        { symbol: 'SOL', amount: 20, avgPrice: 140 }
      ];
    }
    return [
      { symbol: 'BTC', amount: 0.5, avgPrice: 65000 },
      { symbol: 'ETH', amount: 5, avgPrice: 3500 },
      { symbol: 'SOL', amount: 20, avgPrice: 140 }
    ];
  });

  // Сохранение портфолио
  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('cryptoPortfolio', JSON.stringify(portfolio));
    }
  }, [portfolio]);

  // Получение данных о криптовалютах
  const fetchCryptoData = async () => {
    try {
      setLoading(true);
      const ids = cryptoConfig.map(c => c.id).join(',');
      
      const response = await fetch(
        `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${ids}&order=market_cap_desc&sparkline=false&price_change_percentage=24h`,
        {
          method: 'GET',
          headers: {
            'Accept': 'application/json'
          }
        }
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (!data || data.length === 0) {
        throw new Error('Нет данных от API');
      }
      
      const formattedData = data.map(coin => {
        const config = cryptoConfig.find(c => c.id === coin.id);
        return {
          id: coin.id,
          symbol: config?.symbol || coin.symbol.toUpperCase(),
          name: coin.name,
          price: coin.current_price || 0,
          change24h: coin.price_change_percentage_24h || 0,
          marketCap: coin.market_cap || 0,
          volume24h: coin.total_volume || 0,
          icon: config?.icon || '●',
          image: coin.image
        };
      });
      
      setCryptoData(formattedData);
      setLastUpdate(new Date());
      setLoading(false);
    } catch (error) {
      console.error('Ошибка загрузки данных:', error);
      // Fallback data
      setCryptoData([
        {
          id: 'bitcoin',
          symbol: 'BTC',
          name: 'Bitcoin',
          price: 97234.50,
          change24h: 2.34,
          marketCap: 1920000000000,
          volume24h: 42000000000,
          icon: '₿',
          image: 'https://assets.coingecko.com/coins/images/1/large/bitcoin.png'
        },
        {
          id: 'ethereum',
          symbol: 'ETH',
          name: 'Ethereum',
          price: 3342.67,
          change24h: -0.89,
          marketCap: 402000000000,
          volume24h: 18000000000,
          icon: 'Ξ',
          image: 'https://assets.coingecko.com/coins/images/279/large/ethereum.png'
        },
        {
          id: 'solana',
          symbol: 'SOL',
          name: 'Solana',
          price: 189.45,
          change24h: 5.67,
          marketCap: 92000000000,
          volume24h: 3200000000,
          icon: '◎',
          image: 'https://assets.coingecko.com/coins/images/4128/large/solana.png'
        }
      ]);
      setLoading(false);
      setLastUpdate(new Date());
    }
  };

  // Получение данных графика
  const fetchChartData = async (coinId, days) => {
    try {
      const response = await fetch(
        `https://api.coingecko.com/api/v3/coins/${coinId}/market_chart?vs_currency=usd&days=${days}`,
        {
          method: 'GET',
          headers: {
            'Accept': 'application/json'
          }
        }
      );
      
      if (!response.ok) {
        throw new Error('API error');
      }
      
      const data = await response.json();
      
      if (!data.prices || data.prices.length === 0) {
        throw new Error('Нет данных графика');
      }
      
      const formatted = data.prices.map((price, index) => ({
        time: days === 1 
          ? new Date(price[0]).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })
          : new Date(price[0]).toLocaleDateString('ru-RU', { month: 'short', day: 'numeric' }),
        price: price[1],
        index
      }));
      
      setChartData(formatted);
    } catch (error) {
      console.error('Ошибка загрузки графика:', error);
      // Генерация тестовых данных
      const testData = Array.from({ length: 24 }, (_, i) => ({
        time: `${i}:00`,
        price: Math.random() * 10000 + 90000,
        index: i
      }));
      setChartData(testData);
    }
  };

  // Загрузка новостей
  const fetchNews = async () => {
    const mockNews = [
      { title: 'Bitcoin достиг новых максимумов', source: 'CoinDesk', time: '2 часа назад', trend: 'up' },
      { title: 'Ethereum обновление улучшает скорость', source: 'CryptoNews', time: '5 часов назад', trend: 'up' },
      { title: 'Solana показывает рост на 15%', source: 'Decrypt', time: '1 день назад', trend: 'up' }
    ];
    setNews(mockNews);
  };

  // AI функции
  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!inputMessage.trim() || isAITyping) return;

    const userMessage = inputMessage.trim();
    setInputMessage('');
    setChatMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsAITyping(true);

    // Симуляция AI ответа
    setTimeout(() => {
      const aiResponse = generateAIResponse(userMessage);
      setChatMessages(prev => [...prev, { role: 'assistant', content: aiResponse }]);
      setIsAITyping(false);
    }, 1500);
  };

  const generateAIResponse = (message) => {
    const lowerMsg = message.toLowerCase();
    
    if (lowerMsg.includes('портфолио') || lowerMsg.includes('portfolio')) {
      const totalValue = portfolio.reduce((sum, item) => {
        const crypto = cryptoData.find(c => c.symbol === item.symbol);
        return sum + (crypto ? crypto.price * item.amount : 0);
      }, 0);
      
      return `📊 Твое портфолио:\n\nОбщая стоимость: $${totalValue.toLocaleString()}\n\n${portfolio.map(item => {
        const crypto = cryptoData.find(c => c.symbol === item.symbol);
        const value = crypto ? crypto.price * item.amount : 0;
        const profit = crypto ? ((crypto.price - item.avgPrice) / item.avgPrice * 100).toFixed(2) : 0;
        return `${item.symbol}: ${item.amount} ($${value.toLocaleString()}) - ${profit > 0 ? '+' : ''}${profit}%`;
      }).join('\n')}`;
    }
    
    if (lowerMsg.includes('solana') || lowerMsg.includes('sol')) {
      const sol = cryptoData.find(c => c.id === 'solana');
      return sol 
        ? `🌟 Solana сейчас торгуется по $${sol.price.toLocaleString()} с изменением ${sol.change24h > 0 ? '+' : ''}${sol.change24h.toFixed(2)}% за 24ч. Сильная монета с быстрыми транзакциями!`
        : 'Данные по Solana загружаются...';
    }
    
    if (lowerMsg.includes('инвестир') || lowerMsg.includes('invest')) {
      return `💡 Совет:\n\n1. Диверсифицируй - не храни все в одной монете\n2. BTC и ETH - основа портфолио\n3. SOL, ADA - перспективные альткоины\n4. Инвестируй только то, что готов потерять`;
    }
    
    return `🤖 Я вижу твой вопрос про "${message}". Могу помочь с анализом портфолио, рекомендациями по инвестициям или актуальными данными о криптовалютах!`;
  };

  useEffect(() => {
    fetchCryptoData();
    fetchNews();
    const interval = setInterval(fetchCryptoData, 60000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (selectedCrypto) {
      const days = timeframe === '24h' ? 1 : timeframe === '7d' ? 7 : 30;
      fetchChartData(selectedCrypto, days);
    }
  }, [selectedCrypto, timeframe]);

  useEffect(() => {
    if (cryptoData.length > 0 && portfolio.length > 0) {
      const total = portfolio.reduce((sum, item) => {
        const crypto = cryptoData.find(c => c.symbol === item.symbol);
        return sum + (crypto ? crypto.price * item.amount : 0);
      }, 0);
      setPortfolioValue(total);
    }
  }, [cryptoData, portfolio]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isAITyping]);

  const selectedCryptoData = cryptoData.find(c => c.id === selectedCrypto);
  const portfolioData = portfolio.map(item => {
    const crypto = cryptoData.find(c => c.symbol === item.symbol);
    return {
      name: item.symbol,
      value: crypto ? crypto.price * item.amount : 0,
      amount: item.amount
    };
  });

  const COLORS = ['#06b6d4', '#8b5cf6', '#f59e0b', '#10b981', '#ef4444', '#ec4899'];

  if (loading && cryptoData.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-16 h-16 text-cyan-400 animate-spin mx-auto mb-4" />
          <p className="text-xl text-gray-400">Загрузка данных...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-5xl md:text-6xl font-black mb-4 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 text-transparent bg-clip-text font-orbitron">
            CRYPTO DASHBOARD
          </h1>
          <p className="text-gray-400 text-lg flex items-center justify-center gap-2">
            <Sparkles className="w-5 h-5 text-yellow-400" />
            Powered by AI
            <Sparkles className="w-5 h-5 text-yellow-400" />
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {cryptoData.slice(0, 3).map((crypto, index) => (
            <div
              key={crypto.id}
              className="bg-gray-900/50 backdrop-blur-xl border border-gray-800 rounded-2xl p-6 hover:border-cyan-500/50 transition-all cursor-pointer"
              onClick={() => setSelectedCrypto(crypto.id)}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <span className="text-4xl">{crypto.icon}</span>
                  <div>
                    <h3 className="font-bold text-lg">{crypto.symbol}</h3>
                    <p className="text-sm text-gray-500">{crypto.name}</p>
                  </div>
                </div>
                {crypto.change24h >= 0 ? (
                  <TrendingUp className="text-green-400 w-6 h-6" />
                ) : (
                  <TrendingDown className="text-red-400 w-6 h-6" />
                )}
              </div>
              <div className="space-y-2">
                <p className="text-3xl font-bold">${crypto.price.toLocaleString()}</p>
                <p className={`text-sm ${crypto.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h.toFixed(2)}% за 24ч
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Chart */}
        {selectedCryptoData && (
          <div className="bg-gray-900/50 backdrop-blur-xl border border-gray-800 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <span className="text-3xl">{selectedCryptoData.icon}</span>
                {selectedCryptoData.name}
              </h2>
              <div className="flex gap-2">
                {['24h', '7d', '30d'].map(tf => (
                  <button
                    key={tf}
                    onClick={() => setTimeframe(tf)}
                    className={`px-4 py-2 rounded-lg transition-all ${
                      timeframe === tf
                        ? 'bg-cyan-500 text-white'
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="time" stroke="#6b7280" />
                  <YAxis stroke="#6b7280" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1f2937', 
                      border: '1px solid #374151',
                      borderRadius: '8px'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="price" 
                    stroke="#06b6d4" 
                    fillOpacity={1}
                    fill="url(#colorPrice)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Portfolio & News */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Portfolio */}
          <div className="bg-gray-900/50 backdrop-blur-xl border border-gray-800 rounded-2xl p-6">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <DollarSign className="text-green-400" />
              МОЕ ПОРТФОЛИО
            </h3>
            <p className="text-3xl font-bold mb-6">${portfolioValue.toLocaleString()}</p>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={portfolioData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={(entry) => entry.name}
                  >
                    {portfolioData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* News */}
          <div className="bg-gray-900/50 backdrop-blur-xl border border-gray-800 rounded-2xl p-6">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Globe className="text-cyan-400" />
              ПОСЛЕДНИЕ НОВОСТИ
            </h3>
            <div className="space-y-3">
              {news.map((item, index) => (
                <div
                  key={index}
                  className="bg-gray-800/50 rounded-xl p-4 border border-gray-700 hover:border-cyan-500/50 transition-all cursor-pointer"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-bold mb-1">{item.title}</h4>
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <span>{item.source}</span>
                        <span>•</span>
                        <span>{item.time}</span>
                      </div>
                    </div>
                    {item.trend === 'up' && <TrendingUp className="text-green-400 w-5 h-5 flex-shrink-0 ml-2" />}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Chat Button */}
      <button
        onClick={() => setIsChatOpen(!isChatOpen)}
        className="fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg shadow-cyan-500/50 hover:scale-110 transition-transform z-50"
      >
        {isChatOpen ? <MessageSquare className="w-8 h-8 text-white" /> : <Bot className="w-8 h-8 text-white" />}
      </button>

      {/* AI Chat */}
      {isChatOpen && (
        <div className="fixed bottom-24 right-6 w-96 h-[600px] bg-gray-900/95 backdrop-blur-xl border border-cyan-500/30 rounded-2xl shadow-2xl shadow-cyan-500/20 z-50 flex flex-col">
          <div className="bg-gradient-to-r from-cyan-500 to-purple-600 p-4 rounded-t-2xl flex items-center justify-between">
            <div>
              <h3 className="font-bold text-white flex items-center gap-2">
                <Bot className="w-6 h-6" />
                AI Советник
              </h3>
              <p className="text-xs text-gray-200">Задай вопрос о криптовалютах</p>
            </div>
            {chatMessages.length > 0 && (
              <button
                onClick={() => setChatMessages([])}
                className="text-white/80 hover:text-white text-xs px-3 py-1 bg-white/20 rounded-lg hover:bg-white/30 transition-colors"
              >
                Очистить
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {chatMessages.length === 0 && (
              <div className="text-center text-gray-400 mt-4">
                <Bot className="w-16 h-16 mx-auto mb-4 text-cyan-400" />
                <p className="font-bold text-lg text-white mb-2">Привет! 🤖</p>
                <p className="text-sm mb-4">Твой AI советник по криптовалютам</p>
                
                <div className="text-left bg-gray-800/50 rounded-xl p-4 space-y-2 text-sm">
                  <p className="text-cyan-400 font-bold">Попробуй спросить:</p>
                  <button
                    onClick={() => setInputMessage('Проанализируй мое портфолио')}
                    className="w-full text-left p-2 bg-gray-900/50 rounded-lg hover:bg-gray-700/50 transition-colors"
                  >
                    💼 Проанализируй мое портфолио
                  </button>
                  <button
                    onClick={() => setInputMessage('Куда лучше инвестировать?')}
                    className="w-full text-left p-2 bg-gray-900/50 rounded-lg hover:bg-gray-700/50 transition-colors"
                  >
                    📈 Куда лучше инвестировать?
                  </button>
                  <button
                    onClick={() => setInputMessage('Что думаешь про Solana?')}
                    className="w-full text-left p-2 bg-gray-900/50 rounded-lg hover:bg-gray-700/50 transition-colors"
                  >
                    🔮 Что думаешь про Solana?
                  </button>
                </div>
              </div>
            )}
            
            {chatMessages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-xl p-3 ${
                  msg.role === 'user' 
                    ? 'bg-cyan-500 text-white' 
                    : 'bg-gray-800 text-gray-100'
                }`}>
                  <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                </div>
              </div>
            ))}

            {isAITyping && (
              <div className="flex justify-start">
                <div className="bg-gray-800 rounded-xl p-3">
                  <div className="flex gap-2">
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-800">
            <div className="flex gap-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Спроси что-нибудь..."
                className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-cyan-500"
                disabled={isAITyping}
              />
              <button
                type="submit"
                disabled={isAITyping || !inputMessage.trim()}
                className="bg-gradient-to-r from-cyan-500 to-purple-600 text-white p-2 rounded-lg hover:from-cyan-600 hover:to-purple-700 transition-all disabled:opacity-50"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
